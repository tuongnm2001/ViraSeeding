$(function(e) {

    "use strict";
      
      /*===========================================================================
      *
      *  CONFIGURATION DROPDOWN MENUS 
      *
      *============================================================================*/
      $(document).ready(function(){

          $('#set-voice-types').awselect(); 

          $('#set-aws-region').awselect(); 

          $('#set-wasabi-region').awselect(); 

          $('#set-azure-region').awselect(); 

          $('#set-ssml-effects').awselect(); 

          $('#set-storage-option').awselect(); 

          $('#set-file-storage-option').awselect(); 

          $('#set-storage-clean').awselect(); 

          $('#support-category').awselect(); 

          $('#support-priority').awselect(); 

          $('#notification-type').awselect(); 

          $('#notification-action').awselect();

          $('#response-status').awselect();

          $('#user-country').awselect();

          $('#user-status').awselect();

          $('#user-group').awselect();

          $('#smtp-encryption').awselect();

          $('#registration').awselect();

          $('#email-verification').awselect();

          $('#user-role').awselect();

          $('#payment-option').awselect();

          $('#plan-type').awselect();

          $('#plan-status').awselect();

          $('#login-oauth').awselect();

          $('#currency').awselect();

          $('#promo-status').awselect();

          $('#promo-type').awselect();

          $('#promo-usage').awselect();

          $('#invoice-currency').awselect();

          $('#invoice-language').awselect();

          $('#invoice-country').awselect();

          $('#date-format').awselect();

          $('#time-zone').awselect();

          $('#vendor-logo').awselect();

          $('#free-tier-neural').awselect();

      }); 
  
  });
  
  
  